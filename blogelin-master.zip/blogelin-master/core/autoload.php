<?php

include "controller/Core.php";
include "controller/View.php";
include "controller/Module.php";
include "admin/core/controller/Database.php";
include "controller/Executor.php";


include "controller/Lb.php";
include "controller/Model.php";
include "controller/Bootload.php";
include "controller/Action.php";

include "controller/class.upload.php";


include "controller/Html.php";
include "controller/Form.php";
include "controller/Table.php";
include "controller/Bs.php";
include "controller/Crudadmin.php";


?>