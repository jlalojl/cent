<div class="container">
<div class="row">
<div class="col-md-12">
<div class="">
</div>
<div class="row">
<div class="col-md-6">
<img src="index.jpg" class="img-responsive">
</div>



<div class="col-md-6">
<h2>Bienvenido a al portal de noticias TEST</h2>

<p class="lead">Te invitamos a leer noticias, tips y mucho mas</p>

</div>

</div>


</div>
</div>
</div>
<br><br><br><br>