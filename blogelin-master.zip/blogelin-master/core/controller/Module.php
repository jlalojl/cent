<?php



// Module.php
// @brief tareas que se realizan con modulos.

class Module {

	public static function loadLayout(){
		include "core/app/layouts/layout.php";
	}


}



?>
