<div class="content">
<div class="row">
	<div class="col-md-12">
	<h1>Nueva Categoria</h1>
	<br>

	</div>
</div>
</div>